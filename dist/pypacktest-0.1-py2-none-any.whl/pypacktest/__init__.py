def dotest():
    return (u'This is a test. '
            u'This is OK.')
			